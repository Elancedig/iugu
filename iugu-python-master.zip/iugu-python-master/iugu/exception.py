# -*- coding: utf-8 -*-


class ConfigError(Exception):
    pass


class RequiredParameters(Exception):
    pass
